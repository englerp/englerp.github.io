/** Automatically generated file. DO NOT MODIFY */
package myApps.Pokertime;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}