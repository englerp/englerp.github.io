package myApps.Pokertime;

import android.app.TabActivity;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.view.WindowManager;
import android.widget.TabHost;


public class MainScreen extends TabActivity {
  
	public static Pokertimer pokertimer;
	
	public static MainScreen mainscreen;
	
	
	
	
	
	public static void switchtab(int tab)
	{
		mainscreen.getTabHost().setCurrentTab(tab);
        		
	}
	
	
	private void InitControls()
    {
	
	  
	}
	
	
	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		//getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

		pokertimer=new Pokertimer();
		mainscreen=this;
		//setContentView(R.layout.mainscreen);
		
		Resources res = getResources(); // Resource object to get Drawables
	      TabHost tabHost = getTabHost();  // The activity TabHost
	    // TabHost tabHost=(TabHost)findViewById(R.id.tabhost);   
		TabHost.TabSpec spec;  // Reusable TabSpec for each tab
	       Intent intent;  // Reusable Intent for each tab
		
		
		
		
		//Tab 1
	       intent= new Intent(this,TimerScreen.class);
	       //intent.putExtras(session);
	       //intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
	       spec=tabHost.newTabSpec("timer").setIndicator("Timer");
	       spec.setContent(intent);
	       tabHost.addTab(spec);
	       //Tab 2
	       intent= new Intent(this,Settings.class);
	       //intent.putExtras(session);       
	       spec=tabHost.newTabSpec("settings").setIndicator("Settings");
	       spec.setContent(intent);
	       tabHost.addTab(spec);
	       
	     //Tab 3
	       intent= new Intent(this,BlindList.class);
	       //intent.putExtras(session);       
	       spec=tabHost.newTabSpec("blindlist").setIndicator("Blind List");
	       spec.setContent(intent);
	       tabHost.addTab(spec);
	     /*  
	       //Tab 4
	       intent= new Intent(this,ChipCalculator.class);
	       //intent.putExtras(session);       
	       spec=tabHost.newTabSpec("chipcalc").setIndicator("Chip \n calculator");
	       spec.setContent(intent);
	       tabHost.addTab(spec); 
	      */ 
	       
	       tabHost.setCurrentTab(0);
	       //tabHost.setup(); 

	}
	
}
