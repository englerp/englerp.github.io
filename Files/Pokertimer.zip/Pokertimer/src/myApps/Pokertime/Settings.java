package myApps.Pokertime;


import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;

public class Settings extends Activity {
	
	private Button btnOK;
	private EditText tbTime;
	private Pokertimer pokertimer;
	
	
	
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.settings);
       pokertimer=MainScreen.pokertimer;
	   
	
	btnOK=(Button) findViewById(R.id.btnOK);
	tbTime=(EditText)findViewById(R.id.tbTime);
	
	
	
	btnOK.setOnClickListener(new OnClickListener(){

		public void onClick(View v) {
			// TODO Auto-generated method stub
		 pokertimer.PauseTimer();
		 pokertimer.SetTimer(Integer.parseInt(tbTime.getText().toString()));
		 pokertimer.ResetBlinds();
		 
		}});
	
	
	}
	
	
}
