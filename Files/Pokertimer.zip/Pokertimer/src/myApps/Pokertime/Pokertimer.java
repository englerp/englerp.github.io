package myApps.Pokertime;



import java.util.Timer;
import java.util.TimerTask;
import java.util.Vector;



//


public class Pokertimer {

	
	//Constant to identify the state of the timer 
	private final int TIMER_INIT=0; //Timer has not been started yet or has been stopped 
	private final int TIMER_RUNNING=1; //Timer is currently running 
	private final int TIMER_PAUSED=2; //Timer is paused 
    
	
	
	private CustomTask OnTickTask;
	private CustomTask OnBlindsChangeTask;
	
	private int Interval=20*60*1000;  //Time interval between blinds
//    private int Interval=2000;
 
    long Time=0;
	private Timer timer =new Timer();
   
    
	
	private int[] blinds={5,10,25,50,100,200,400};  //Default Blinds

	
	private Vector bld;
	private int CurrentIndex=0; //Currently selected blind
    
   
    private int timerState=TIMER_INIT; //Current timer  state 
    
    
    
    
    public static  Pokertimer pokeref; 
    
    
    public Pokertimer()
    {
      
      pokeref=this;
      bld=new Vector();
      
      for(int i=0;i<blinds.length ;i++)
    	 bld.addElement(new Integer(blinds[i]));
      
      
      
    }
    
    private void InitCalendar()
    {
    	Time=Interval;	
    }
    
   
    
    //Set the value of the blind at the specified index
	public void SetBlind(int index, int value)
	{
		if (index>=0&&index<bld.size())
			bld.setElementAt(new Integer(value),index);
		 
	}
	
	//Delete the specified index 
	
	public void DeleteBlind(int index)
	{ 
	   
	   if(index>=0&&index<bld.size())
		 bld.removeElementAt(index);
	   if (CurrentIndex>=bld.size())
		   CurrentIndex=bld.size()-1;
	}
    
	
	//Get the value of the blind at the specified index 
	public int GetBlind(int index)
	{
		
		if(index>=0&&index<bld.size())
		  return ((Integer)bld.elementAt(index)).intValue();
		else return -1;
		
	}
	
//	Get the list of values for the Blinds
	public Vector GetBlindList()
	{ 
		return  bld;
	}
	
	
//	Append a new blind to the end of the list 
	public void AppendBlind(int value)
	{
		bld.setSize(bld.size()+1);
		bld.setElementAt(new Integer(value), bld.size()-1);
		Sort();
	   
	}
	
	//Get the index of the Blind currently used
	public int getCurrentBlindIndex()
	{
		return CurrentIndex;
	}
	
	
	public int getCurrentBlind()
	{
		if (CurrentIndex>=0 && CurrentIndex<bld.size());
		return ((Integer)bld.elementAt(CurrentIndex)).intValue();
	}
	
	//At a new blind at the specified index with the specified value
	public void AddBlind(int index, int value)
	{
		if(index>0&&index<bld.size())
		bld.insertElementAt(new Integer(value), index);
	}
	
	
	//Set the amount of time between blinds in minutes
	public void SetTimer(int minutes)
	{
	  Interval=minutes*60*1000;	 
    }
	
	public long GetCurrentInterval()
	{
		return Interval/60000;
	}
	
	
	//pause the timer
	public void PauseTimer()
	{
		timer.cancel();
 		timer.purge();
		timerState=TIMER_PAUSED;
	}
	
	//if the timer is in the TIMER_INIT State initialize the CalendarObject
	//in any case, set up a new timerObject and change the timerState to TIMER_RUNNING 
	public void StartTimer()
	{
		int period=1000;
		
	switch(timerState)
	{
	case TIMER_INIT:
		InitCalendar();
		timerState=TIMER_PAUSED;
		StartTimer();
		break;
		
	case TIMER_PAUSED:
	  timer=new Timer();
      timer.scheduleAtFixedRate(new IncTask(),0,period);     
	  timerState=TIMER_RUNNING;
	  
	System.out.println("Timer started");
	  break;
	}
	
	
	}  
	
	
	
	//Reset the the timer and the CalendarObject 
	public void Reset()
	{
       timer.cancel();
       timerState=TIMER_INIT;
       InitCalendar();
       CurrentIndex=0;  
       
	}
	
	public void ResetBlinds()
	{
		InitCalendar();
	}
	
	
	//Get the number of remaining minutes
	public long GetRemMinutes()
	{
		return Time/1000/60;
	}
	
	//Get the number of remaining seconds within the current minute
	public long GetRemSeconds()
	{
	   return (Time/1000)%60;
	}
	
	
	public void GotoNextBlind()
	{
		if (CurrentIndex<bld.size()-1)
			CurrentIndex++;
		else CurrentIndex=0;
		
	}
	
	//Go to the next blind if the CurrentIndex is smaller than the number of blinds -1
    private void IncreaseIndex()
    {
       if (CurrentIndex<bld.size()-1)
       { 
        System.out.println(CurrentIndex+" : "+ bld.elementAt(CurrentIndex));
        CurrentIndex++;
        
       }
       else 
       {
         System.out.println("Finished");
         timer.cancel();
         
       }
    }

    
    //The task scheduled by the Timerobject
    //adda a second to the calendarobject and fires the OnTickEvent 
    //if the Calendarobject reaches 0 the index of the currently used blind is incremented 
    //and the calendar Object is reset
    class IncTask extends TimerTask
    {
    	public void run()
    	{
    		
    		Time-=1000;
    		System.out.println("time:"+Time);
    		
//    		fireOnTickEvent(new OnTickEvent(this));
    	    fireOnTickEvent();
    		if (Time<=0)
    		{
    		  IncreaseIndex();
    		  System.out.println("B:Time="+Time+"Interval="+Interval);
    		  Time=Interval;
    		  
    		  System.out.println("A:Time="+Time+"Interval="+Interval);
    		  fireOnBlindsChangeEvent();
    		}
    	}
    }
	
    private void exchange(int A, int B)
    {
    	int x=((Integer)bld.elementAt(A)).intValue();
    	bld.setElementAt(bld.elementAt(B), A);
    	bld.setElementAt(new Integer(x), B);
    }
    
    
    public void Sort()
    {
     int i,j;
     int x; 
     for (i=0;i<bld.size()-1;i++)
       for (j=i+1;j<bld.size();j++)
            if (((Integer)bld.elementAt(i)).intValue()>((Integer)bld.elementAt(j)).intValue())exchange(i,j);
    }
    

	
    
    public void AddOnTickTas(CustomTask t)
    {
    	OnTickTask=t;
    }
    
    
    public void AddOnBlindsChangeTask(CustomTask task)
    {
    	OnBlindsChangeTask=task;
    }
    
    
    
    protected void fireOnTickEvent()
    {
        if(OnTickTask!=null)
    	OnTickTask.todo();
    }
    
    protected void fireOnBlindsChangeEvent()
    {
    	
    	if(OnBlindsChangeTask!=null)
    	   OnBlindsChangeTask.todo();
    	
    	
    }
    
	
}


