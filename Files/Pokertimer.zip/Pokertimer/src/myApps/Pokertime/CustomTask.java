package myApps.Pokertime;

public interface CustomTask {
   public void todo();
}
