package myApps.Pokertime;


import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class ChipCalculator extends Activity {

	
	EditText tbAmount5;
	EditText tbAmount10;
	EditText tbAmount25;
	EditText tbAmount50;
	EditText tbAmount100;
	TextView lbResult;
	Button   btnResult;
	
	
	public void Calculate()
	{
	  int Sum=0;
	  Sum+=Integer.parseInt(tbAmount5.getText().toString())*5;
	  Sum+=Integer.parseInt(tbAmount10.getText().toString())*10;
	  Sum+=Integer.parseInt(tbAmount25.getText().toString())*25;
	  Sum+=Integer.parseInt(tbAmount50.getText().toString())*50;
	  Sum+=Integer.parseInt(tbAmount100.getText().toString())*100; 
  	  
	  lbResult.setText(""+Sum);
	 	
	}
	
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		
		super.onCreate(savedInstanceState);
		setContentView(R.layout.chipcalculator);
		
		
		tbAmount5=(EditText)findViewById(R.id.tbAmount5);
		tbAmount10=(EditText)findViewById(R.id.tbAmount10);
		tbAmount25=(EditText)findViewById(R.id.tbAmount25);
		tbAmount50=(EditText)findViewById(R.id.tbAmount50);
		tbAmount100=(EditText)findViewById(R.id.tbAmount100);
		btnResult=(Button)findViewById(R.id.btnCalculate);
		lbResult=(TextView)findViewById(R.id.lbResult);
		
		
		btnResult.setOnClickListener(new OnClickListener(){

			public void onClick(View v) {
				// TODO Auto-generated method stub
				Calculate();
			}});
		
		
		
	}
	
}
