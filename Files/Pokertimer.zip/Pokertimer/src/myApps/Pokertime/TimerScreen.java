package myApps.Pokertime;

import java.util.HashMap;


import android.app.Activity;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class TimerScreen extends Activity {
	
	private Button btnStart;
	private Button btnPause;
	private Button btnSkip;
	private TextView lbTime;
	private TextView lbBlinds;
	private TextView lbChipText;
	private ImageView imgChip;
	private Pokertimer pokertimer;
	private HashMap<Integer,Integer> Chipcolors;
	private MediaPlayer mp;
	private boolean State=false;
	
	
	private void ToggleState()
	{
	   State=!State;
	   if (State)
	   { 
		 btnStart.setBackgroundColor(R.drawable.pause);
		 pokertimer.StartTimer();
		 
	   }else
	   {
		  btnStart.setBackgroundColor(R.drawable.play);
		  pokertimer.StartTimer();
		   
	   }
		
	}
	
	
	private void ThreadRef()
    {
		 this.runOnUiThread(new Runnable(){

				public void run() {
					Refresh();
					// TODO Auto-generated method stub
					
				}});	
		
	}
	
	
	private String FormatNumber(long n)
	{
	 if ((n+"").length()==1)	
		return "0"+n;
	 else return ""+n;
	}
	
	private void Refresh()
	{
			lbTime.setText(FormatNumber(pokertimer.GetRemMinutes())+":"+ FormatNumber(pokertimer.GetRemSeconds()));
			
			
			int idChip=R.drawable.yellow;
		
			if (Chipcolors.containsKey(pokertimer.getCurrentBlind()))
				idChip=Chipcolors.get(pokertimer.getCurrentBlind());
			imgChip.setImageResource(idChip);
			lbChipText.setText(""+pokertimer.getCurrentBlind());
	}
	
	private void Alert()
	{
		if (mp==null)
		{mp=MediaPlayer.create(TimerScreen.this, R.raw.mgs);
		 mp.start();
		 mp.setLooping(true);
		 
		}
		pokertimer.PauseTimer();
	}
	
	
	
	
	
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.timerscreen);
     pokertimer=MainScreen.pokertimer;    
     pokertimer.SetTimer(1);
    
     
     Chipcolors=new HashMap<Integer,Integer>();
      Chipcolors.put(5, R.drawable.red);
      Chipcolors.put(10, R.drawable.white);
      Chipcolors.put(25, R.drawable.green);
      Chipcolors.put(50, R.drawable.blue);
      Chipcolors.put(100, R.drawable.black);
       
      
     
     
     
     btnStart=(Button)findViewById(R.id.StartButton);
     btnPause=(Button)findViewById(R.id.PauseButton);
     btnSkip=(Button)findViewById(R.id.SkipButton);
     
     lbTime=(TextView)findViewById(R.id.TimeView);
     lbTime.setText("test");
     
     lbBlinds=(TextView)findViewById(R.id.lbBlinds);
     lbChipText=(TextView)findViewById(R.id.lbChipText);
     
     imgChip=(ImageView)findViewById(R.id.imgChip);
    
     imgChip.setImageResource(R.drawable.yellow);
    
     pokertimer.AddOnTickTas(new CustomTask(){

 		public void todo () {
 			// TODO Auto-generated method stub
 			ThreadRef();
 		}});
     
     pokertimer.AddOnBlindsChangeTask(new CustomTask(){

		public void todo() {
			// TODO Auto-generated method stub
			Alert();
		}});
     
     
     
     
     btnStart.setOnClickListener(new OnClickListener(){

		public void onClick(View v) {
			// TODO Auto-generated method stub
			 pokertimer.StartTimer();
			//ToggleState();
			if (mp!=null)
				mp.stop();
		}});
    btnPause.setOnClickListener(new OnClickListener(){

		public void onClick(View v) {
			// TODO Auto-generated method stub
			pokertimer.PauseTimer();
			if (mp!=null)
				mp.stop();
		}}); 
    
    btnSkip.setOnClickListener(new OnClickListener(){

		public void onClick(View v) {
			// TODO Auto-generated method stub
			pokertimer.PauseTimer();
			pokertimer.GotoNextBlind();
			pokertimer.ResetBlinds();
			if (mp!=null)
				mp.stop();
			Refresh();
		}});
      pokertimer.SetTimer(20);
      Refresh();  
    }
	
}
