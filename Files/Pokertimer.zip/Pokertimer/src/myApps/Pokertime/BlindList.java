package myApps.Pokertime;

import java.util.ArrayList;
import java.util.Vector;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.ContextMenu;
import android.view.MenuItem;
import android.view.View;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

public class BlindList extends Activity {
	
	ListView BlindList;
	Button btnBlindOk;
	EditText tbNewBlind;
	private final int CONTEXT_MENU_DELETE=1;
	
	public void PopulateList()
	{
	  ArrayList<Integer> contents=new ArrayList<Integer>();
	  Vector<Integer> temp=MainScreen.pokertimer.GetBlindList();
	  for (int i=0;i<temp.size();i++)
		contents.add(temp.get(i));
	  BlindList.setAdapter(new ArrayAdapter<Integer>(this,R.layout.listitem,contents));
	  registerForContextMenu(BlindList);	
	 
	  
	}
	

	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		  super.onCreate(savedInstanceState);
	        setContentView(R.layout.blindlist);
	        btnBlindOk=(Button)findViewById(R.id.btnBlindOK);
	  	  tbNewBlind=(EditText)findViewById(R.id.tbNewBlind);
	  	  
	  	  
	  	  btnBlindOk.setOnClickListener(new OnClickListener(){

	  		public void onClick(View v) {
	  			// TODO Auto-generated method stub
	  			MainScreen.pokertimer.AppendBlind(Integer.parseInt(tbNewBlind.getText().toString()));
	  		    PopulateList();
	  		}});
	  	   
	       
	        
	        
	       BlindList=(ListView)findViewById(R.id.blindlist); 
	       PopulateList(); 
	
	   
	}
	
	public void DeleteEntry(int pos)
	{
	 MainScreen.pokertimer.DeleteBlind(pos);
	 PopulateList();
		
	}
	
	
	public void onCreateContextMenu(ContextMenu menu, View view, ContextMenuInfo menuInfo)
	{
		AdapterView.AdapterContextMenuInfo info;
		try {
		    info = (AdapterView.AdapterContextMenuInfo) menuInfo;
		} catch (ClassCastException e) {
		    Log.e("ERROR", "bad menuInfo", e);
		    return;
		}
		
		menu.add(0, CONTEXT_MENU_DELETE, 0, "Delete");
		
	}
	
	
	public boolean onContextItemSelected(MenuItem item)
	{
		AdapterView.AdapterContextMenuInfo info;
		
		try {
			 info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
			 int  position  =(int) BlindList.getAdapter().getItemId(info.position);
             switch(item.getItemId())
			 {
			 case CONTEXT_MENU_DELETE:
			 {
				 DeleteEntry(position);
				 break;
			 }
			
				 
			 }
			 
			 
			 return true;
		
		} catch (ClassCastException e) {
		    Log.e("ERROR", "bad menuInfo", e);
		    return false;
		
		
		
		}
		
		
	}
	
	

}
