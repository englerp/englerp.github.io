package myApps.Pokertime;




import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

public class main extends Activity {
    /** Called when the activity is first created. */
    
	public static Pokertimer pokertimer;
	
	@Override
    public void onCreate(Bundle savedInstanceState) {
        
    	pokertimer=new Pokertimer();
    	super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
       
    	Intent intent=new Intent(getApplication() ,MainScreen.class);
		startActivity(intent);
    	
        
    }
}